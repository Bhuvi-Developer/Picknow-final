import React from 'react';
import Carousel from './Carousel';
import ShinyText from './ShinyText';
import './LandingPage.css';
import dryFruit1 from '../../assets/dry-fruits.jpg';
import honey from '../../assets/honey.jpg'
import Nuts from '../../assets/Nuts.jpg'
import { FaSearch, FaShoppingCart, FaHeart, FaLink, FaStar } from 'react-icons/fa';


const ProductCard = ({ image, title, price, rating }) => {
  return (
    <div className="noo-product-inner">
      <div className="noo-product-thumbnail">
        <a href="#">
          <img src={image} alt={title} />
        </a>
        <div className="noo-rating">
          {[...Array(5)].map((_, index) => (
            <FaStar
              key={index}
              color={index < rating ? "#ffc107" : "#e4e5e9"}
              size={14}
            />
          ))}
        </div>
      </div>
      <div className="noo-product-title">
        <h3><a href="#">{title}</a></h3>
        <span className="price">
          <span className="amount">${price}</span>
        </span>
      </div>
      <div className="noo-product-action">
        <div className="noo-action">
          {/* <button className="quick-view" title="Quick View">
            <FaSearch />
          </button> */}
          <button className="add-to-cart" title="Add to Cart">
            <FaShoppingCart />
          </button>
          <button className="add-to-wishlist" title="Add to Wishlist">
            <FaHeart />
          </button>
          <button className="view-details" title="View Details">
            <FaLink />
          </button>
        </div>
      </div>
    </div>
  );
};

const LandingPage = () => {
  const products = [
    {
      id: 1,
      image: dryFruit1,
      title: "Premium Dry Fruits Mix",
      price: "24.99",
      rating: 5
    },
    {
      id: 2,
      image: honey,
      title: "Organic Mixed Nuts",
      price: "19.99",
      rating: 4
    },
    {
      id: 3,
      image: Nuts,
      title: "Raw Forest Honey",
      price: "15.99",
      rating: 5
    },
    // {
    //   id: 4,
    //   image: "https://via.placeholder.com/300x300",
    //   title: "Fresh Medjool Dates",
    //   price: "12.99",
    //   rating: 4
    // }
  ];

  return (
    <div className="landing-page">
      <section className="hero-section">
        <Carousel />
      </section>

      <section className="welcome-section">
        <ShinyText 
          text="Welcome to PickNow" 
          speed={3} 
          className="welcome-title"
        />
        <p className="welcome-subtitle">Discover Nature's Finest Selection</p>
      </section>

      <section className="products-section">
        <h2>Best sellers</h2>
        <div className="products-grid">
          {products.map(product => (
            <ProductCard 
              key={product.id}
              image={product.image}
              title={product.title}
              price={product.price}
              rating={product.rating}
            />
          ))}
        </div>
      </section>

      <section className="cta-section">
        <div className="cta-content">
          <h2>Start Shopping Today</h2>
          <p>Experience the finest quality natural products</p>
          <button className="cta-button">Shop Now</button>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
