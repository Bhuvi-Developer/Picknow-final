import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './Carousel.css';
import dryFruit1 from '../../assets/dry-fruits.jpg'
import Nuts from '../../assets/Nuts.jpg'
import honey from '../../assets/honey.jpg'

const Carousel = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: true,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false
        }
      }
    ]
  };

  const slides = [
    {
      id: 1,
      imageUrl: dryFruit1,
      title: 'Special Offers',
      description: 'Exclusive deals just for you'
    },
    {
      id: 2,
      imageUrl: Nuts,
      title: 'New Arrivals',
      description: 'Check out our latest products'
    },
    {
      id: 3,
      imageUrl: honey,
      title: 'Best Sellers',
      description: 'Our most popular items'
    }
  ];

  return (
    <div className="carousel-wrapper">
      <Slider {...settings}>
        {slides.map(slide => (
          <div key={slide.id} className="slide">
            <div className="slide-content">
              <img src={slide.imageUrl} alt={slide.title} />
              <div className="slide-overlay">
                <h2>{slide.title}</h2>
                <p>{slide.description}</p>
                <button className="slide-button">Shop Now</button>
              </div>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Carousel;
